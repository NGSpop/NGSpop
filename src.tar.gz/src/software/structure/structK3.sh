echo Start Time :
date
/ifshk5/PC_PA_EU/USER/maolikai/bin/structure/structure2.3.4
echo End Time :
date
